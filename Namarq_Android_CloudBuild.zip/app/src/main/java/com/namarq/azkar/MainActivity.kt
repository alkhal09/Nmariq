package com.namarq.azkar

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Green = Color(0xFF145C56)
private val Gold = Color(0xFFD6AA54)
private val Cream = Color(0xFFF7F2E8)
private val Card = Color(0xFFFFFCF5)

data class Dhikr(val title: String, val text: String, val count: Int = 1)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ar")
        }
        setContent { NamarqApp { speak(it) } }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "namarq")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun NamarqApp(onSpeak: (String) -> Unit) {
    var screen by remember { mutableStateOf("welcome") }
    var selected by remember { mutableStateOf<Dhikr?>(null) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            secondary = Gold,
            background = Cream,
            surface = Card
        )
    ) {
        when (screen) {
            "welcome" -> WelcomeScreen { screen = "home" }
            "home" -> HomeScreen(
                onOpen = { d -> selected = d; screen = "detail" },
                onList = { screen = "list" }
            )
            "detail" -> DetailScreen(
                dhikr = selected ?: morning.first(),
                onBack = { screen = "home" },
                onSpeak = onSpeak
            )
            "list" -> DhikrListScreen(
                onBack = { screen = "home" },
                onOpen = { d -> selected = d; screen = "detail" },
                onSpeak = onSpeak
            )
        }
    }
}

@Composable
fun WelcomeScreen(onStart: () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Green).padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("☪", fontSize = 54.sp, color = Gold)
            Text("نمارق", fontSize = 56.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(Modifier.height(14.dp))
            Text("زادك اليومي من الأذكار", fontSize = 22.sp, color = Color.White, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Text("معًا في طريق الطمأنينة وقرب الله", fontSize = 16.sp, color = Color.White.copy(alpha=.9f), textAlign = TextAlign.Center)
            Spacer(Modifier.height(42.dp))
            Button(
                onClick = onStart,
                colors = ButtonDefaults.buttonColors(containerColor = Gold),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth(.8f).height(56.dp)
            ) {
                Text("ابدأ الآن  →", color = Green, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun HomeScreen(onOpen: (Dhikr) -> Unit, onList: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Cream)) {
        Column(Modifier.padding(20.dp)) {
            Text("نمارق", fontSize = 34.sp, color = Green, fontWeight = FontWeight.Bold)
            Text("السلام عليكم", fontSize = 25.sp, color = Green, fontWeight = FontWeight.Bold)
            Text("اللهم اجعل هذا اليوم مليئًا بالذكر والطمأنينة", color = Green)
            Spacer(Modifier.height(16.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = Green),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth().clickable { onOpen(morning.first()) }
            ) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("أذكار الصباح", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("للبداية المطمئنة", color = Color.White.copy(alpha=.85f))
                    }
                    Icon(Icons.Default.PlayArrow, contentDescription = "تشغيل", tint = Gold)
                }
            }
            Spacer(Modifier.height(16.dp))
            val cards = listOf(
                "☀" to "أذكار الصباح",
                "☾" to "أذكار المساء",
                "⌂" to "أذكار الصلاة",
                "♥" to "أذكار متنوعة",
                "⌛" to "أذكار النوم",
                "☆" to "أذكار خاصة"
            )
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(cards.chunked(2)) { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { (icon, title) ->
                            Card(
                                modifier = Modifier.weight(1f).clickable { if (title == "أذكار متنوعة") onList() else onOpen(morning.first()) },
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(containerColor = Card)
                            ) {
                                Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(icon, fontSize = 28.sp, color = Gold)
                                    Text(title, color = Green, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                                    Text("🔊", fontSize = 18.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DetailScreen(dhikr: Dhikr, onBack: () -> Unit, onSpeak: (String) -> Unit) {
    var count by remember { mutableStateOf(dhikr.count) }
    Column(Modifier.fillMaxSize().background(Cream)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "رجوع") }
            Text(dhikr.title, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 24.sp, color = Green, fontWeight = FontWeight.Bold)
            IconButton(onClick = { onSpeak(dhikr.text) }) {
                Icon(Icons.Default.VolumeUp, contentDescription = "استماع", tint = Green)
            }
        }
        Card(
            Modifier.fillMaxWidth().padding(18.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Card)
        ) {
            Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("🔊", fontSize = 34.sp, modifier = Modifier.clickable { onSpeak(dhikr.text) })
                Spacer(Modifier.height(10.dp))
                Text(dhikr.text, fontSize = 23.sp, lineHeight = 42.sp, color = Green, textAlign = TextAlign.Center)
                Spacer(Modifier.height(20.dp))
                Text("عدد التكرار", color = Green)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FilledIconButton(onClick = { if (count > 1) count-- }) { Text("−", fontSize = 22.sp) }
                    Text("$count", Modifier.padding(horizontal = 22.dp), fontSize = 24.sp, color = Green)
                    FilledIconButton(onClick = { count++ }) { Text("+", fontSize = 22.sp) }
                }
                Spacer(Modifier.height(16.dp))
                Button(onClick = { onSpeak(dhikr.text) }, colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                    Icon(Icons.Default.VolumeUp, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("استماع إلى الذكر")
                }
            }
        }
    }
}

@Composable
fun DhikrListScreen(onBack: () -> Unit, onOpen: (Dhikr) -> Unit, onSpeak: (String) -> Unit) {
    val all = morning + evening + listOf(
        Dhikr("أذكار النوم", "باسمك اللهم أموت وأحيا", 1),
        Dhikr("أذكار السفر", "سبحان الذي سخر لنا هذا وما كنا له مقرنين", 1),
        Dhikr("أذكار الطعام", "الحمد لله الذي أطعمنا وسقانا وجعلنا مسلمين", 1),
        Dhikr("أذكار الاستيقاظ", "الحمد لله الذي أحيانا بعدما أماتنا وإليه النشور", 1)
    )
    Column(Modifier.fillMaxSize().background(Cream)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "رجوع") }
            Text("أذكار متنوعة", Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 24.sp, color = Green, fontWeight = FontWeight.Bold)
        }
        LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(all) { d ->
                Card(
                    Modifier.fillMaxWidth().clickable { onOpen(d) },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Card)
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { onSpeak(d.text) }) {
                            Icon(Icons.Default.VolumeUp, contentDescription = "استماع", tint = Green)
                        }
                        Column(Modifier.weight(1f)) {
                            Text(d.title, color = Green, fontSize = 19.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                            Text("اضغط للاستماع والقراءة", color = Color.Gray, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth())
                        }
                        Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = Green)
                    }
                }
            }
        }
    }
}

val morning = listOf(
    Dhikr("أذكار الصباح", "اللهم إني أسألك خير هذا اليوم وخير ما بعده، وأعوذ بك من شر هذا اليوم وشر ما بعده", 1),
    Dhikr("أذكار الصباح", "رضيت بالله ربًا، وبالإسلام دينًا، وبمحمد صلى الله عليه وسلم نبيًا", 3)
)
val evening = listOf(
    Dhikr("أذكار المساء", "أمسينا وأمسى الملك لله والحمد لله، لا إله إلا الله وحده لا شريك له", 1),
    Dhikr("أذكار المساء", "اللهم إني أسألك خير هذه الليلة وخير ما فيها", 1)
)
