package com.namarq.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    int purple = Color.rgb(123,74,179);
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showHome();
    }
    TextView tv(String text,int size,boolean bold){
        TextView t=new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(Color.rgb(35,30,40));
        t.setTypeface(Typeface.DEFAULT, bold?Typeface.BOLD:Typeface.NORMAL); t.setGravity(Gravity.RIGHT); t.setPadding(20,14,20,14); return t;
    }
    Button btn(String text){
        Button x=new Button(this); x.setText(text); x.setTextSize(15); x.setTextColor(Color.WHITE); x.setBackgroundColor(purple); return x;
    }
    void showHome(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(22,30,22,12);
        TextView logo=tv("نمارق",30,true); logo.setTextColor(purple); logo.setGravity(Gravity.CENTER);
        root.addView(logo,new LinearLayout.LayoutParams(-1,70));
        root.addView(tv("فرصتك تبدأ من هنا",22,true));
        root.addView(tv("ابحث عن الوظائف والخدمات والفرص المناسبة لك.",16,false));
        EditText search=new EditText(this); search.setHint("ابحث عن وظيفة أو مهارة"); search.setTextSize(16); search.setGravity(Gravity.RIGHT);
        root.addView(search,new LinearLayout.LayoutParams(-1,60));
        root.addView(tv("أحدث الفرص",20,true));
        addJob(root,"موظف مبيعات","الخرطوم","دوام كامل");
        addJob(root,"مصمم جرافيك","الخرطوم","عمل حر");
        addJob(root,"فني صيانة","بحري","دوام جزئي");
        setContentView(root);
    }
    void addJob(LinearLayout root,String title,String place,String type){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(12,8,12,8);
        card.setBackgroundColor(Color.rgb(246,243,248));
        card.addView(tv(title,18,true)); card.addView(tv(place+"  •  "+type,14,false));
        Button more=btn("عرض التفاصيل"); card.addView(more);
        more.setOnClickListener(v -> Toast.makeText(this,"سيتم إضافة تفاصيل الوظيفة قريبًا",Toast.LENGTH_SHORT).show());
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,8,0,8); root.addView(card,p);
    }
}
